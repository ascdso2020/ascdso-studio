*******
Install
*******

Requirements
============

* Docker Engine
* docker-py

Install
=======

.. code-block:: bash

  $ sudo pip install docker-py
