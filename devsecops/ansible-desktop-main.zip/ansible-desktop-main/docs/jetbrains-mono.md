# JetBrains Mono Font

JetBrains Mono is well documented on [JetBrain's website](https://www.jetbrains.com/lp/mono/).

## VS Code changes

Text

```txt
editor.fontFamily
‘Jetbrains Mono’,'Droid Sans Mono', 'monospace', monospace, 'Droid Sans Fallback'
```

JSON

```json
"editor.fontFamily":
  "‘Jetbrains Mono’,'Droid Sans Mono', 'monospace', monospace, 'Droid Sans Fallback'"
```
