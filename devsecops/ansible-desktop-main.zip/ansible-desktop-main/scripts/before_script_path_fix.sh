#!/bin/sh
sudo cp home-local-bin.sh /etc/profile.d/home-local-bin.sh
sudo chmod 0644 /etc/profile.d/home-local-bin.sh
