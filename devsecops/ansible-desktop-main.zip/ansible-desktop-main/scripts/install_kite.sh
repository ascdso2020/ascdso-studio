#!/bin/sh
bash -c "$(wget -q -O - https://linux.kite.com/dls/linux/current)"
